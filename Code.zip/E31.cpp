#include<iostream>
#define SIZE 5
using namespace std;
class deque
{
	int queue[SIZE];
	int L,R;
	public:
	deque()
	{
		L = -1;
		R = -1;
	}
	void insert_r(int x)
	{
		if(L == (R+1)%SIZE)
		{
			cout<<"\nQueue Overflow"<<endl;
		}
		else if(R == -1)
		{ 
			L = 0; 
			R = 0; 
			queue[R] = x;
		}
		else 
		{ 
			R = (R+1) %SIZE;
			queue[R] = x;
		}
	}
	void insert_L(int x)
	{
		if(L == (R+1)%SIZE)
		{
			cout<<"\nQueue Overflow"<<endl;
		}
		else if(L == -1)
		{ 
			L = 0;
			R = 0;
			queue[R] = x;
		}
		else 
		{ 
			L = (L+SIZE-1) %SIZE; 
			queue[L] = x;
		}
	}
	int delete_r()
	{
		int x;
		if(L == -1)
		{
			cout<<"\nQueue Underflow"<<endl;
		}
		else if(L == R)
		{ 
			x = queue[L]; 
			L = -1; 
			R = -1; 
		}
		else
		{
			x = queue[R];
			R = (R+SIZE-1)%SIZE;
		}
		return x;
	}
	int delete_L()
	{
		int x;
		if(L == -1) 
		{
			cout<<"\nQueue Underflow";
		}
		else if(L == R)
		{
			x = queue[L]; 
			L = -1; 
			R = -1; 
		}
		else 
		{
			x = queue[L];
			L = (L+1)%SIZE;
		}
		return x;
	}
	void display()
	{
		int i;
		if(L<=R)
		{
			for(i=L;i<=R;i++)
				cout<<queue[i]<<"-->\t";
		}
		else
		{
			for(i=0;i<=R;i++)
				cout<<queue[i]<<"-->\t";
			for(i=L;i<SIZE;i++)
				cout<<queue[i]<<"-->\t";
		}
	}
};
int main()
{
	deque d;
	char choice;
	int x;
	do
	{
		cout<<"1: Insert From Left \n";
		cout<<"2: Insert From Right\n";
		cout<<"3: Delete From left\n";
		cout<<"4: Delete From Right\n";
		cout<<"5: Display\n";
		cout<<"6: Exit Program\n";
		cout<<"Enter Your Choice:";
		cin>>choice;
		switch(choice)
		{
			case '1':
				cout<<"\nEnter Integer Data :"<<endl;
				cin>>x;
				d.insert_L(x);
				break;
			case '2':
				cout<<"\nEnter Integer Data :"<<endl;
				cin>>x;
				d.insert_r(x);
				break;
			case '3':
				cout<<"\nDeleted Data From Front End:---- \n",d.delete_L();
				break;
			case '4':
				cout<<"\nDeleted Data From Back End:---- \n",d.delete_r();
				break;
			case '6':
				exit(0);
				break;
			case '5':
				d.display();
				break;
		}
	}while(choice!=6);
	return 0;
}

