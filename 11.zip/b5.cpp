///*

//Write C++ program to generate snowflake using concept of fractals.

#include <iostream>
#include <graphics.h>
#include<math.h>
using namespace std;


void koch_curve(int x1,int y1,int x2,int y2,int iter){
    if (iter==0){
    line(x1,y1,x2,y2);
    return;
    }else{
    float p1x,p1y,p2x,p2y,ix,iy;
//delay(10);
    p1x = (2*x1+x2)/3;
    p2x = (x1+2*x2)/3;
    p1y = (2*y1+y2)/3;
    p2y = (y1+2*y2)/3;
    ix=(int)(0.5*(x1+x2)+sqrt(3)*(y1-y2)/6);
    iy=(int)(0.5*(y1+y2)+sqrt(3)*(x2-x1)/6);
    
    //next calls
    koch_curve(x1,y1,p1x,p1y,iter-1);
    koch_curve(p1x,p1y,ix,iy,iter-1);
    koch_curve(ix,iy,p2x,p2y,iter-1);
    koch_curve(p2x,p2y,x2,y2,iter-1);
    }
}

int main()
{
    int gd = DETECT,gm;
    initgraph(&gd,&gm,NULL);
    //triangle 
    int iterations=5;
    //cin>>iterations;
    koch_curve(250,50,120,125,iterations);
    koch_curve(120,125,250,200,iterations);
    koch_curve(250,200,250,50,iterations);
    
    getch();
    closegraph();
    return 0;
}
//*/

/*

//Write C++ program to generate Hilbert curve using concept of fractals.

#include <iostream>
#include <stdlib.h>
#include <graphics.h>
#include <math.h>

using namespace std;

void move(int j,int h,int &x,int &y)
{
if(j==1)
y-=h;
else if(j==2)
x+=h;
else if(j==3)
y+=h;
else if(j==4)
x-=h;
lineto(x,y);
}

void hilbert(int r,int d,int l,int u,int i,int h,int &x,int &y)
{
if(i>0)
{
i--;
hilbert(d,r,u,l,i,h,x,y);
move(r,h,x,y);
hilbert(r,d,l,u,i,h,x,y);
move(d,h,x,y);
hilbert(r,d,l,u,i,h,x,y);
move(l,h,x,y);
hilbert(u,l,d,r,i,h,x,y);
}
}

int main()
{
int n,x1,y1;
int x0=50,y0=150,x,y,h=10,r=2,d=3,l=4,u=1;

cout<<"\nGive the value of n: ";
cin>>n;
x=x0;y=y0;
int gm,gd=DETECT;
initgraph(&gd,&gm,NULL);
moveto(x,y);
hilbert(r,d,l,u,n,h,x,y);
delay(10000);

closegraph();

return 0;
}
*/

/*

//Write C++ program to generate fractal patterns by using Koch curves.

#include<graphics.h>
#include<iostream>
#include<math.h>
using namespace std;
void koch(int x1, int y1, int x2, int y2, int it)
{
 float angle = 60*M_PI/180;
 int x3 = (2*x1+x2)/3;
 int y3 = (2*y1+y2)/3;

 int x4 = (x1+2*x2)/3;
 int y4 = (y1+2*y2)/3;

 int x = x3 + (x4-x3)*cos(angle)+(y4-y3)*sin(angle);
 int y = y3 - (x4-x3)*sin(angle)+(y4-y3)*cos(angle);

 if(it > 0)
 {
  koch(x1, y1, x3, y3, it-1);
  koch(x3, y3, x, y, it-1);
  koch(x, y, x4, y4, it-1);
  koch(x4, y4, x2, y2, it-1);
 }
 else
 {

  line(x1, y1, x3, y3);
  line(x3, y3, x, y);
  line(x, y, x4, y4);
  line(x4, y4, x2, y2);
 }
}

int main()
{
 int gd = DETECT, gm;
 initgraph(&gd, &gm,NULL);
 int x1 = 100, y1 = 100, x2 = 400, y2 = 400;
 koch(x1, y1, x2, y2, 4);
 delay(5000);
 closegraph();
 return 0;
}
*/
