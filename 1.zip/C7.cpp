/*
Write a program in C++ to use map associative container. The keys will be the names of states and the values will be the populations of the states. 
When the program runs, the user is prompted to type the name of a state. The program then looks in the map, using the state name as an index and 
returns the population of the state.
*/

#include <iostream>  
#include <map>  
using namespace std;  

class st
{
	public:
	map<string, int> state; 
	st()
	{
		state["Uttar Pradesh"] = 199812341;  
		state["Maharashtra"] = 112374333; 
		state["Bihar"] = 104099452; 
		state["West Bengal"] = 91276115; 
		state["Andhra Pradesh"] = 84580777; 
	}
	void display()
	{
		for( map<string,int>::iterator ii=state.begin(); ii!=state.end(); ++ii)  
   		{  
       		cout << (*ii).first << ": " << (*ii).second << endl;  
   		} 	
	}
	void popu()
	{
		cout << "Map size: " << state.size() << endl; 
	}
	void insert()
	{
		int count ;
		cout<<"Enter number of states you want to enter data : ";
		cin>>count;
    	string name;
    	int pop;
		for(int i = 0; i < count+1; i++)
	    {
	        cout << "Enter " << count << " States' Name and population " << endl;
	        cout << "Name of the state : ";
	        cin.ignore();
	        getline(cin,name);
	        cout << "Population of the state: ";
	        cin >> pop;
	        state.insert(pair<string, int>(name, pop));
			count--;
    	}
	}
	 int retpop(string sta) 
	 { 	
	 	return state[sta]; 
	 }
};

int main()  
{   
   int choice,x;
   st p;
   string sta;
   do{
   		cout<<"Enter your choice: ";
		cout<<"\n1. Insert data";
		cout<<"\n2. Display data ";
		cout<<"\n3. Number of States' data present";
		cout<<"\n4. Find population of any state";
		cout<<"\n5. Exit \n";
   		cin>>choice;
   		switch(choice)
   		{
   			case 1:
   				p.insert();
   				break;
   			case 2:
   				p.display();
   				break;
   			case 3:
   				p.popu();
   				break;
   			case 4:
   				p.display();
   				cout<<"Enter name of state of which you want to know the population : "<<endl;
   				cin.ignore();
	 			getline(cin,sta);
	 			x=p.retpop(sta);
   				if(x==0)
   				{
   					cout<<"Invalid state"<<endl;
				}
   				else
   				{
   					cout<<"Population of "<<sta<<" is "<<x<<endl;	
				}
				break;
   			case 5:
   				break;
		}
   }while(choice!=5);
   return 0;
}  
