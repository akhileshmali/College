//Write C++ program using STL for sorting and searching user defined records such as personal records (Name, DOB, Telephone number etc) using vector container.
#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
class per_info
{ 
	public:
		string name,dob,tel;
	    void display()
	    {
			cout<<"Name :"<<name<<endl;
			cout<<"Date of birth :"<<dob<<endl;
			cout<<"Telephone no :"<<tel<<endl<<endl;
	    }
};
vector<per_info>pr;
vector<string>na;
vector<string>db;
vector<string>tl;
void insert()
{
	per_info x;
	cout<<"Enter name of the person:"<<endl;
	cin.ignore();
	getline(cin,x.name);
	cout<<"Enter the date of birth of the person:"<<endl;
	getline(cin,x.dob);
	cout<<"Enter the telephone no of the person:"<<endl;
	getline(cin,x.tel);
	pr.push_back(x);
}
int sb;
bool cmp(per_info o1, per_info o2) 
{
   switch(sb) 
   {
        case 1:
            return o1.name < o2.name;
            break;
        case 2:
            return o1.dob < o2.dob;
            break;
        case 3:
            return o1.tel < o2.tel;
            break;
        default:
            return o1.name < o2.name;
            break;
   }
}
int main()
{
	string target;
	int choice;
	do
	{
		cout<<"Enter your choice: ";
		cout<<"\n1. Insert in record";
		cout<<"\n2. Display the record ";
		cout<<"\n3. Search in the record";
		cout<<"\n4. Sort the record";
		cout<<"\n5. Exit \n";
		cin >> choice; 
		switch (choice)
		{
		    case 1:
		    	 insert();
				 break;
			case 2:
				 for (int i=0; i<pr.size();i++)
				 {
				 	pr[i].display();
				 }
				 break;
			case 3:
			 	int ch;
			 	cout<<"Enter choice : ";
			 	cout<<"\n1. Search Name ";
			 	cout<<"\n2. Search Date of Birth ";
			 	cout<<"\n3. Search Telephone number "<<endl;
			 	cin>>ch;
			 	switch(ch)
			 	{
			 	 	case 1:
			 	 		for (int i = 0; i < pr.size(); i++)
						 {
						 	na.push_back(pr[i].name);
						 }
						 cout << "Enter the name to be searched in the record:\n";
						 cin.ignore();
						 getline(cin,target);
						 if (binary_search(na.begin(), na.end(), target))
						 {
						 	cout <<"The person with name "<<target<<" is present in the record"<<endl;
						 }
						 else
						 {
						 	cout <<"The person with name "<<target<< " is not present in the record"<<endl;
						 }
			 	 		break;
			 	 	case 2:
			 	 		for (int i = 0; i < pr.size(); i++)
						 {
						 	db.push_back(pr[i].dob);
						 }
						 cout << "Enter the Date of Birth to be searched in the record : "<<endl;
						 cin.ignore();
						 getline(cin,target);
						 if (binary_search(db.begin(), db.end(), target))
						 {
						 	cout <<"The person with Date of Birth "<<target<<" is present in the record"<<endl;
						 }
						 else
						 {
						 	cout << "The person with Date of Birth "<<target<<" is not present in the record"<<endl;
						 }
			 	 		break;
			 	 	case 3:
			 	 		 for (int i = 0; i < pr.size(); i++)
						 {
						 	tl.push_back(pr[i].tel);
						 }
						 cout << "Enter the Telephone Number to be searched in the record :\n";
						 cin.ignore();
						 getline(cin,target);
						 if (binary_search(tl.begin(), tl.end(), target))
						 {
						 	cout << "The person with Telephone Number "<<target<<" is present in the record\n";
						 }
						 else
						 {
						 	cout << "The person with Telephone Number "<<target<<" is not present in the record\n";
						 }
			 	 	     break;
			 	 	default:
			 	 		break;
				}
				break;
			case 4:
			 	cout << "Enter your choice:";
				cout<<"\n1. Sort by Name ";
			 	cout<<"\n2. Sort by Date of Birth ";
			 	cout<<"\n3. Sort by Telephone number "<<endl;
			    cin >> sb;
			    sort(pr.begin(), pr.end(), cmp);
			    cout << "\nSorted Records:" << endl;
			    for (int i=0; i<pr.size();i++)
				{
				 	pr[i].display();
				}
			    cout << endl;
				break;
			case 5:
				cout<<"Thank You "<<endl;
			  	break;
			default: 
			 	cout<<"Invalid choice"<<endl;
			 	break; 
			}
		 }while(choice!=5);
}

