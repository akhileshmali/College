# PASS 1 OF TWO PASS ASSEMBLER

class initialize:
	AD={"START":1,"END":2,"ORIGIN":3,"EQU":4,"LTORG":5}
	IS={"STOP":00,"ADD":1,"SUB":2,"MULT":3,"MOVER":4,"MOVEM":5,"COMP":6,"BC":7,"DIV":8,"READ":9,"PRINT":10}
	DL={"DS":1,"DC":2}
	RG={"AREG":1,"BREG":2,"CREG":3,"DREG":4}
	CC={"EQ":1,"LT":2,"GT":3,"LE":4,"GE":5,"NE":6,"ANY":7}
	
	
class assembler:
	input_file=open("input.txt",r)
	input_file.seek(0)
	loc_ctr=0
	self.initialize()
	read_file=input_file.readline()
	for i in read_file:
		if i=="START":
			
	
